# iNotes для Android

Это устанавливаемое веб-приложение (PWA), а не APK. Оно работает офлайн и хранит заметки локально в браузере телефона.

## Публикация через GitHub Pages
1. Загрузите все файлы из архива в корень публичного репозитория `inotes`.
2. В GitHub откройте Settings → Pages.
3. В разделе Build and deployment выберите Deploy from a branch, branch `main`, folder `/ (root)`, затем Save.
4. Откройте `https://aidarkemal.github.io/inotes/` в Chrome.
5. В меню браузера выберите Install app / Add to Home screen.

## Важно о синхронизации
Сейчас заметки хранятся только на устройстве. Для синхронизации между устройствами нужно отдельно создать Firebase-проект, включить Email/Password Authentication и Firestore, затем добавить конфигурацию Firebase и код синхронизации. Не вводите секреты в публичный репозиторий.
